"""Wind mail monitor package."""
